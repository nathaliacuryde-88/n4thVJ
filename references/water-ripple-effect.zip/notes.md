# Feedback tunnel

What to take: use the image from the camera. The effect follow the hands and distort it as a water transparent effect. Should be used with the hand commands, but also in auto with music and later be also manipulated by this tool parameters.